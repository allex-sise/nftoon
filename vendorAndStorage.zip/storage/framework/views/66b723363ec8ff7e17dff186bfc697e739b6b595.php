<?php
$img = explode(",",@$data['item']->item_image->image);
?>
<div class="banner-area3 gray-bg">
    <div class="banner-area-inner">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 offset-xl-3">
                    <div class="banner-info mb-30">
                        <div class="over_view_thumb imaginebanner">
                                
                            <div class="overlay_with_btn">
                            <div class="overlay_inner">
                               
                                <button class="boxed-btn-white"  onclick="ImgShow()"><?php echo app('translator')->get('lang.screenshoot'); ?></button>
                                <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key != 0): ?>
                                <a class="popup-image hit" href="<?php echo e(asset(@$item)); ?>"></a>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                            </div>
                        </div>
                        <h1 style="color: #000; text-align: center; padding: 20px;"><?php echo e(@$data['item']->title); ?> </h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
.imaginebanner{
    -webkit-box-shadow: 0px 0px 12px 0px rgb(50 50 50 / 75%)!important;
    -moz-box-shadow: 0px 0px 12px 0px rgba(50, 50, 50, 0.75)!important;
    box-shadow: 0px 0px 12px 0px rgb(50 50 50 / 75%)!important;
    margin-top: 150px!important;
    height: 700px!important;
    width: auto!important;
}
}
.banner-area3 h1 {
    font-size: 30px;
    font-family: "Quicksand", sans-serif;
    font-weight: 700;
    color: #000!important;
    line-height: 48px!important;
    text-align: center!important;
    padding: 20px!important;
}
.banner-area3 .banner-area-inner .banner-info {
    margin-bottom: 50px!important;
}
</style><?php /**PATH /Applications/AMPPS/www/mintedz/resources/views/frontend/partials/itemHeader.blade.php ENDPATH**/ ?>