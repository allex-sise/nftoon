<?php 
$homepage = Modules\Pages\Entities\InfixHomePage::where('active_status', 1)->first();
?> 

<div class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-xl-8 offset-xl-2">
                    <div class="banner-info text-center">
                        <h2><?php echo e(@$homepage->homepage_title); ?></h2>
                        
                        <h4><?php echo e(@$homepage->homepage_description); ?></h4>
                    </div>
                 
                </div>
            </div>
        </div>
    </div><?php /**PATH /Applications/AMPPS/www/mintedz/resources/views/frontend/partials/banner.blade.php ENDPATH**/ ?>