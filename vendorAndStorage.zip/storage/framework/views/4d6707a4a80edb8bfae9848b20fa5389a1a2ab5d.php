
<?php $__env->startPush('css'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/')); ?>/index_modal.css">

<?php $__env->stopPush(); ?>
<?php 
    $homepage = Modules\Pages\Entities\InfixHomePage::where('active_status', 1)->first();
?> 
<?php $__env->startSection('content'); ?>
<style>
.banner-area::before, .banner-area2::before, .banner-area3::before, .banner-area4::before{
    background-image: url("<?php echo e(asset('public/frontend/imaginibanner/hmm.png')); ?>")!important;
    background-size: contain;
    background-repeat: no-repeat;
    margin-top: 85px;
}
.banner-area2{
    height: 700px;
}
.section-padding1 {
    padding-top: 20px;
    padding-bottom: 120px;
}
    </style>
<input type="text" id="_categor_id" hidden value="<?php echo e($data['category']->id); ?>">
<input type="text" id="_subcategor_id" hidden value="<?php echo e(@$data['subcategory']); ?>">
<input type="text" id="_tag" hidden value="<?php echo e(@$data['tag']); ?>">
<input type="text" id="_attribute" hidden value="<?php echo e(@$data['attribute']); ?>">
<input type="text" id="_key" hidden value="<?php echo e(@$data['key']); ?>">
<input type="text" id="searCat" hidden value="<?php echo e(@$data['searCat']); ?>">
  <!-- banner-area start -->
    <div class="banner-area2" >
        <div class="container">
            <div class="row">
                <div class="col-xl-8 offset-xl-2">
                    <!-- <div class="banner-info text-center mb-30">
                        <h2><?php echo e(@$data['sub_cat']? @$data['sub_cat']->title :@$data['category']->title); ?></h2>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
    <!-- banner-area end -->
    <!-- categori-menu-area-start -->
    <div class="categori-menu-area d-lg-block Common_cat_menu">
            <div class="container-fluid ">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="catagori-menu ">
                            <nav>
                                <ul class="Common_cat_menu_list" >
                                    <?php if(!@$data['sub_cat']): ?>
                                    <li>
                                        <div class="catagori-submenu-area mb-40">
                                            <div class="catagori-submenu-inner">
                                                <span href="javascript:;" class="submenu-close"> <i class="ti-close"></i> </span>
                                                <div class="catagori-content">
                                                    <ul>
                                                        <?php $__currentLoopData = $data['sub_category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                            
                                                        <li><a href="<?php echo e(route('categoryItem',[@$data['category']->slug,@$item->slug])); ?>"><?php echo e(@$item->title); ?> <span> (<?php echo e(@$item->CountItem( @$data['category']->id,@$item->id)); ?>)</span></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </li>                                        
                                    <?php endif; ?>
                                    

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- categori-menu-area-end -->
    <!-- latest-goods-start -->
    <div class="latest-goods-area gray-bg section-padding1 mt-40">
        <div class="container">
            <div class="row align-items-end">
                <div class="col-xl-12  portfolio-menu">                   

                     <?php if(@$data['category']): ?>
                     <font><button class="active"><?php echo e(@$data['category']->title); ?></button></font>
                     <?php endif; ?>
                     <?php if(@$data['sub_cat']): ?>
                     <font><button class="active"><?php echo e(@$data['sub_cat']->title); ?></button></font>
                     <?php endif; ?>

                     <?php if(@$data['tag']): ?>
                     <font><button class="active"><?php echo e(@$data['tag']); ?></button></font>
                     <?php endif; ?>
                     <?php if(@$data['attribute']): ?>
                     <font><button class="active"><?php echo e(@$data['attribute']); ?></button></font>
                     <?php endif; ?>
                     <?php if(@$data['key']): ?>
                     <font><button class="active"><?php echo e(@$data['key']); ?></button></font>
                     <?php endif; ?>
                     <?php if(@$data['category']): ?>
                     <font><button onclick="window.location.href = '<?php echo e(URL('/')); ?>';" class="active"><?php echo app('translator')->get('lang.clear_filter'); ?></button></font>
                 <?php endif; ?>
                     <font class="filter_cat_sale"></font>
                     <font class="filter_cat_rate"></font>
                </div>

                <div class="col-xl-6">
                    <div class="section-title mb-40">
                        <h3><?php echo e(@$homepage->product_title); ?></h3>
                        <!-- <h4><?php echo e(@$homepage->product_title_description); ?></h4> -->
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="portfolio-menu portfolio-menu2 text-xl-right text-lg-left text-sm-center">
                            <button class="active" value="all" id="all" data-filter="*"><?php echo app('translator')->get('lang.all_items'); ?></button>
                            <button data-filter=".cat2" value="newest" id="newest"><?php echo app('translator')->get('Newest'); ?></button>
                            <button data-filter=".cat4" value="trending" id="trending"><?php echo app('translator')->get('lang.Trending'); ?></button>
                    </div>
                </div>
            </div>
            <div class="row grid databox" id="databox">

            </div>
            <div class="row bt">
            </div>
        </div>
    </div>
    <!-- latest-goods-end -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('public/frontend/js/')); ?>/category.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/mintedz/resources/views/frontend/pages/category.blade.php ENDPATH**/ ?>