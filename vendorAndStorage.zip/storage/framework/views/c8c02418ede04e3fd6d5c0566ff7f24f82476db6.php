 <!-- footer-start -->
 <style>
.colspecial{
    margin: 0 auto;
    display: block;
}
.footer-area .footer-top {
    padding-top: 50px;
    padding-bottom: 25px;
}
.footer-area .footer-top .footer-widget .footer-logo {
    margin-bottom: 30px;
    margin-top: 10px;
}
.footer-area .copyright-area .social-links li a {
    width: 30px;
    height: 30px;
    font-size: 18px;
    color: aliceblue;
    display: inline-block;
    background: transparent;
    text-align: center;
    line-height: 30px;
    -webkit-transition: 0.5s;
    -moz-transition: 0.5s;
    -ms-transition: 0.5s;
    -o-transition: 0.5s;
    transition: 0.5s;
}
.footer-area .copyright-area .footer-bottom .footer-link {
    margin-bottom: 0px;
}
 </style>
 <footer>
    <?php
        $logo_conditions = ['title'=>'Logo', 'active_status'=>1];
        $logopic = dashboard_background($logo_conditions);
    ?>
    <div class="footer-area footer-bg">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 colspecial">
                        <div class="row">
                        <?php
                                $custom_link=InfixFooterMenu();
                            ?>
                            <?php if($custom_link!=''): ?>
                                
                        
                            <div class="col-md-4">
                                <div class="footer-widget">
                                    <div class="footer-title">
                                        <h3><?php echo e($custom_link->title2); ?></h3>
                                    </div>
                                    <div class="footer-list">
                                        <nav>
                                            <ul>
                                            <?php if($custom_link->link_href1!=''): ?>
                                                  <li><a href="<?php echo e(url($custom_link->link_href1)); ?>"><?php echo e($custom_link->link_label1); ?> </a></li>
                                                  
                                                <?php endif; ?>
                                                    <?php if($custom_link->link_href2!=''): ?>
                                                    <li><a href="<?php echo e($custom_link->link_href2); ?>"><?php echo e($custom_link->link_label2); ?></a></li>
                                                
                                                <?php endif; ?>
                                                <?php if($custom_link->link_href6!=''): ?>
                                                <li><a href="<?php echo e(url($custom_link->link_href6)); ?>"><?php echo e($custom_link->link_label6); ?></a></li>
                                      
                                                <?php endif; ?>
                                              
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="footer-widget text-center">
                                    <div class="footer-logo"> 
                                       <a href="<?php echo e(url('/')); ?>">
                                            <img src="<?php echo e(@$logopic ? asset($logopic->image) : asset('public/frontend/img/Logo.png')); ?>" alt="" class="mw">
                                        </a>
                                    </div>
                                    <div class="copyright-area">
                                    <div class="social-links text-center">
                                    <nav>
                                        <ul>
                                            <?php echo getSocialIconsDynamic(); ?> 
                                        </ul> 
                                    </nav>
                                </div>
                                </div>
                                    <!-- <div class="community-area">
                                            <?php
                                            $getData=App\ManageQuery::FooterSellCount();
                                                @$ItemEarning=$getData['ItemEarning'];
                                            ?>
                                        <div class="total-community">
                                            <?php
                                                $system_settings=app('infix_general_settings');
                                            ?>
                                            <h3> <?php echo e(@$system_settings->currency_symbol); ?> <?php echo e(isset($ItemEarning) ? round($ItemEarning) : 0); ?></h3>
                                            <p><?php echo app('translator')->get('lang.total_community_earnings'); ?></p>
                                        </div>
                                        <div class="total-community second">
                                            <?php
                                                @$ItemSale=$getData['ItemSale'];

                                            ?>
                                            <h3><?php echo e(@$ItemSale); ?></h3>
                                            <p><?php echo app('translator')->get('lang.total_items_sold'); ?></p>
                                        </div>
                                    </div>  -->
                                </div>
                            </div>
                          
                            <div class="col-md-4">
                                <div class="footer-widget">
                                    <div class="footer-title">
                                        <h3 class="text-right"><?php echo e($custom_link->title3); ?></h3>
                                    </div>
                                    <div class="footer-list">
                                        <nav>
                                            <ul class="text-right">
                                             <?php if($custom_link->link_href3!=''): ?>
                                                    <li><a href="<?php echo e($custom_link->link_href3); ?>"><?php echo e($custom_link->link_label3); ?></a></li>
                                               <?php endif; ?>
                                                    <?php if($custom_link->link_href7!=''): ?>
                                                        <li><a href="<?php echo e($custom_link->link_href7); ?>"><?php echo e($custom_link->link_label7); ?></a></li>
                                                    <?php endif; ?>
                                                    <?php if($custom_link->link_href11!=''): ?>
                                                        <li><a href="<?php echo e($custom_link->link_href11); ?>"><?php echo e($custom_link->link_label11); ?></a></li>
                                                    <?php endif; ?>
                                                    <?php if($custom_link->link_href15!=''): ?>
                                                        <li><a href="<?php echo e($custom_link->link_href15); ?>"><?php echo e($custom_link->link_label15); ?></a></li>
                                                    <?php endif; ?>
                                                
                                                <?php if(@Auth::user()->role_id == 4 || @Auth::user()->role_id == 5): ?>   
                                                   <li><a href="<?php echo e(route('user.refundRequest')); ?>"><?php echo app('translator')->get('lang.Refund'); ?></a></li>
                                                <?php endif; ?>
                                                <?php if($custom_link->link_href10!=''): ?>
                                                <li><a href="<?php echo e($custom_link->link_href10); ?>"><?php echo e($custom_link->link_label10); ?></a></li>
                                      
                                                <?php endif; ?>
                                                <?php if($custom_link->link_href14!=''): ?>
                                                <li><a href="<?php echo e($custom_link->link_href14); ?>"><?php echo e($custom_link->link_label14); ?></a></li>
                                           
                                               <?php endif; ?>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-10 offset-xl-1">
                        <div class="line-border mb-20"></div>
                        <div class="row ">
                            <div class="col-xl-7 col-md-12 col-lg-7">
                                <div class="footer-bottom">
                                    <div class="footer-link">
                                        <nav>
                                            <ul>
                                                <?php
                                                    $menus = FooterMenu();
                                                ?>
                                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                <a href="<?php echo e($menu->menu_url); ?>"><?php echo e($menu->menu_title); ?></a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </nav>
                                    </div>
                                
                                   
                                </div>
                            </div>
                            <div class="col-xl-5 col-md-12 col-lg-5">
                                <div class="social-links mb-0">
                                <?php
                                         $footer_link=InfixFooterSetting();
                                    ?>
                                    <p class="copy-right-text mb-0" style="margin-top: -13px;"><?php echo e(@$footer_link->copyright_text); ?>. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer-end --><?php /**PATH /Applications/AMPPS/www/mintedz/resources/views/frontend/partials/footer.blade.php ENDPATH**/ ?>